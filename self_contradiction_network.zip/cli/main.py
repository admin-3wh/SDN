# CLI entry point for SCN
