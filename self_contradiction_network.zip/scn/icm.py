# Inference Chain Memory (ICM) logic
