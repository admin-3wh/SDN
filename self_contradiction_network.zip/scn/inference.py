# Inference class and data structure
