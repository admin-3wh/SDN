# Contradiction detection logic
