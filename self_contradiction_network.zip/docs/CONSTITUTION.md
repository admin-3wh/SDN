# SCN Constitution v0.1
