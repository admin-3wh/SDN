# Self-Contradiction Network (SCN)

An intelligent agent that learns by confronting and resolving contradictions in its own belief system.
