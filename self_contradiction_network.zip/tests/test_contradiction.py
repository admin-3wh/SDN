# Tests for contradiction detection
