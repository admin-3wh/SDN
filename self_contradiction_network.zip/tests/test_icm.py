# Tests for ICM logic
