# Tests for Inference class
